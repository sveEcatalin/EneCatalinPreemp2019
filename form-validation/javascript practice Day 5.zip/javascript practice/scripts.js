document.getElementById("firstName").addEventListener("blur", function(event) {
    var value = document.getElementById("firstName").value;
    if (value == "") {
        document.getElementById("firstName").setAttribute("style", "border: 1px solid red;");
    } else {
        document.getElementById("firstName").setAttribute("style", "border: 1px solid #777777;");
    }
});